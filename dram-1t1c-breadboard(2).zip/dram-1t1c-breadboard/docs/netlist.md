# Net list and parts

| Net | Pins on it | Level |
|---|---|---|
| +V rail | supply positive; S1 side B; M2 drain; J1 (write 1 position) | supply voltage |
| GND rail | supply negative; R1 lower leg; C1 lower leg; R2 lower leg; DMM black lead; J1 (write 0 position) | 0 V |
| WL | S1 side A; R1 upper leg; M1 gate | high while S1 pressed, 0 V through R1 otherwise |
| DATA | M1 drain; fixed end of J1 | high, 0 V or floating, set by J1 |
| SN | M1 source; C1 upper leg; M2 gate | the stored bit |
| OUT (TP1) | M2 source; R2 upper leg; DMM red lead | follows SN minus M2's gate-source drop |

| Ref | Part | Value |
|---|---|---|
| M1, M2 | 2N7000 N-channel MOSFET, TO-92 | Vth about 2 V (0.8 to 3 V) |
| C1 | ceramic disc capacitor | 1 nF (102), 10 nF (103), 100 nF (104) |
| R1 | carbon film resistor | 100 kΩ |
| R2 | carbon film resistor | 10 kΩ |
| S1 | tactile push button | momentary, 4-leg |
| DMM | digital multimeter | DC volts, 20 V range |

Notes from the build:

- Check each 2N7000's pin order with the multimeter diode test before inserting it; some makers reverse source and drain.
- Never probe SN directly. A 10 MΩ meter on a 1 nF capacitor discharges it in about 10 ms.
- Keep fingers off the SN strips while measuring; skin oil leaks more than the transistor does.
