# 1T1C DRAM cell on a breadboard

A one-transistor, one-capacitor (1T1C) DRAM cell built from two 2N7000 MOSFETs, a ceramic capacitor, two resistors and a push button. We wrote a bit onto the capacitor, read it back through a source follower, and measured how fast the charge leaks away for three capacitor values.

![Bench setup](images/bench_setup.jpg)

## What the circuit does

- **M1 (2N7000)** is the pass transistor. While the word line (WL, the push button S1) is high, M1 connects DATA (jumper J1) to the storage node (SN), and the capacitor C1 charges to that level. That is the write.
- **C1** holds the bit as charge once S1 is released and M1 turns off. Leakage slowly drains it, which is why real DRAM needs refresh.
- **M2 (2N7000)** is a source follower: SN drives its gate, and the multimeter reads its source (TP1) across a 10 kΩ load. The gate draws almost no current, so the stored bit can be read without draining it.
- **R1 (100 kΩ)** pulls WL to 0 V when the button is released.

The net list and parts list are in [`docs/netlist.md`](docs/netlist.md).

![Breadboard close-up](images/breadboard_closeup.jpg)

## Video

A recording of the TP1 voltage dropping during a decay run: [watch on Google Drive](https://drive.google.com/file/d/1eQCKTBf8Ft37lhtTifwjZiIoS96-J-Aj/view?usp=drivesdk).

## Method

1. Write a 1: J1 on the high rail, press S1, release S1, then unplug J1 so DATA floats.
2. Read TP1 with a DMM (20 V DC range, 2-decimal resolution) at 0, 10, 30, 60 and 120 s after releasing S1, timed by stopwatch.
3. Swap C1 (1 nF, 10 nF, 100 nF), discharge by writing a 0, and repeat.

## Results

Raw readings are in [`data/measurements.csv`](data/measurements.csv).

| C1 | 0 s | 10 s | 30 s | 60 s | 120 s | Retention (0.5 V drop) |
|---|---|---|---|---|---|---|
| 1 nF (102) | 5.92 V | 4.43 V | 3.24 V | 2.18 V | 4.5 mV | about 3.4 s |
| 10 nF (103) | 5.96 V | 5.62 V | 5.50 V | 5.43 V | 5.32 V | about 47 s |
| 100 nF (104) | 5.97 V | 5.63 V | 5.61 V | 5.57 V | 5.56 V | more than 120 s |

Retention is the time for TP1 to fall 0.5 V from its written value, linearly interpolated between readings.

![TP1 decay curves](images/decay_curves.png)

Leakage was estimated from I = C × dV/dt over each interval ([`data/results.csv`](data/results.csv)):

| Interval | 1 nF | 10 nF | 100 nF |
|---|---|---|---|
| 0 to 10 s | 149 pA | 340 pA | 3400 pA |
| 10 to 30 s | 60 pA | 60 pA | 100 pA |
| 30 to 60 s | 35 pA | 23 pA | 133 pA |
| 60 to 120 s | n/a (TP1 below M2 threshold) | 18 pA | 17 pA |

The 10 to 30 s row is the window that matches the roughly 60 pA, 60 pA and 100 pA we first noted in our lab notebook.

![Leakage by interval](images/leakage_by_interval.png)

## What we observed

- **Bigger capacitor, slower decay.** Retention went from about 3.4 s (1 nF) to about 47 s (10 nF), and 100 nF lost only 0.41 V in two minutes. The 10 nF case is about 14 times slower than 1 nF, in the same direction as the 10 times expected from capacitance alone.
- **The 1 nF cell read 4.5 mV at 120 s.** TP1 reads about 0 once SN falls below M2's threshold, even though some charge is still on the capacitor. This is the same call a DRAM sense amplifier has to make between 0 and 1.
- **The leakage is not a single constant.** It is highest right after the write and falls as the voltage falls, so one "pA" figure per capacitor hides this. That is why the table is split by interval.
- **A fast initial drop for the large capacitors.** Both 10 nF and 100 nF lost about 0.34 V in the first 10 s. A true leakage current would remove far less voltage from the bigger capacitor, so this looks like a settling effect rather than leakage. Possible causes are charge injection when S1 releases and dielectric absorption in the ceramic capacitors, but we have not tested either.
- **The written 1 was higher than the guide predicted.** TP1 read about 5.9 V right after writing, while the guide we followed expected 2.5 to 4.5 V from a 9 V battery. we used a bench supply instead of a battery, and 2N7000 thresholds vary a lot from part to part, so we would not read much into the difference without logging the actual rail voltages.

## Limitations

- One run per capacitor, with hand-timed readings and a 0.01 V meter resolution. For 100 nF, 0.01 V over 20 s is a 50 pA uncertainty, so its later-interval leakage figures are rough.
- TP1 follows SN only while M2 conducts, so the leakage numbers are approximate and stop being valid near M2's threshold.
- No temperature control, and one pair of transistors.
- Not done: the J1-at-0 V variant, charge injection step, temperature and refresh runs from the guide.

## Ideas for a second run

- Read at 1, 2, 3 and 5 s to see the initial drop in detail.
- Log TP1 with the oscilloscope instead of hand-timing.
- Repeat with J1 tied to 0 V to compare off-state leakage through M1.

## Reproduce the plots

```bash
pip install -r requirements.txt
python3 analysis/analyze.py
```

## Repo layout

```
README.md
requirements.txt
data/measurements.csv      raw TP1 readings
data/results.csv           per-interval leakage estimates
analysis/analyze.py        analysis and plots
images/                    bench photos and generated plots
docs/                      net list, parts list and build notes
LICENSE                    MIT license
```

## Credits

Course project, chosen and carried out by a team from VIT Vellore (B.Tech Electronics and VLSI Design, October 2026):

- Kaluri Venkata Annaji Harshavardhan
- Yerrawar Sri Raghava
- Avish Choudhury
- Divvya Srivastava

## License

MIT, see [LICENSE](LICENSE).
