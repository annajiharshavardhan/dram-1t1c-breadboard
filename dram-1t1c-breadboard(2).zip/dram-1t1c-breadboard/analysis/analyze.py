"""Analyse the 1T1C DRAM breadboard decay measurements.

Reads  data/measurements.csv
Writes data/results.csv, images/decay_curves.png, images/leakage_by_interval.png

Leakage is estimated from I = C * dV/dt over each interval between readings.
TP1 is the source-follower output, so it follows the storage node (SN) only
while M2 conducts. Intervals that end below M2's threshold are excluded.

Run from the repo root:  python3 analysis/analyze.py
"""
import csv
from collections import OrderedDict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "measurements.csv"
OUT_RESULTS = ROOT / "data" / "results.csv"
IMG = ROOT / "images"
IMG.mkdir(exist_ok=True)

RESOLUTION_V = 0.01  # meter shows 2 decimals, so each reading is about +/-0.005 V
THRESHOLD_V = 0.1  # TP1 below this: M2 is off, TP1 no longer tracks SN
RETENTION_DROP_V = 0.5

# Categorical slots 1-3 (blue, orange, aqua), fixed order = capacitor order
COLORS = ["#2a78d6", "#eb6834", "#1baf7a"]
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
SURFACE, GRID, AXIS = "#fcfcfb", "#e1e0d9", "#c3c2b7"


def load():
    series = OrderedDict()
    with open(DATA, newline="") as f:
        for row in csv.DictReader(f):
            s = series.setdefault(
                row["capacitor"],
                {"C_nF": float(row["capacitance_nF"]), "t": [], "v": []},
            )
            s["t"].append(float(row["time_s"]))
            s["v"].append(float(row["tp1_V"]))
    return series


def retention_time(t, v, drop=RETENTION_DROP_V):
    """Linear-interpolated time for TP1 to fall `drop` volts below its t=0 value."""
    target = v[0] - drop
    for i in range(1, len(t)):
        if v[i] <= target:
            frac = (v[i - 1] - target) / (v[i - 1] - v[i])
            return t[i - 1] + frac * (t[i] - t[i - 1])
    return None  # not reached within the record


def intervals(s):
    rows = []
    C = s["C_nF"] * 1e-9
    for i in range(1, len(s["t"])):
        dt = s["t"][i] - s["t"][i - 1]
        dv = s["v"][i - 1] - s["v"][i]
        tracks = s["v"][i] > THRESHOLD_V
        rows.append(
            {
                "t0": s["t"][i - 1],
                "t1": s["t"][i],
                "slope_V_per_s": dv / dt,
                "I_pA": C * dv / dt * 1e12,
                "err_pA": C * RESOLUTION_V / dt * 1e12,
                "valid": tracks,
            }
        )
    return rows


def style(ax):
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(AXIS)
    ax.tick_params(colors=MUTED, labelsize=9)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def plot_decay(series):
    fig, ax = plt.subplots(figsize=(7.5, 4.6), facecolor=SURFACE)
    style(ax)
    for (name, s), color in zip(series.items(), COLORS):
        ax.plot(
            s["t"], s["v"], color=color, linewidth=2, marker="o",
            markersize=6, markeredgecolor=SURFACE, markeredgewidth=1.5,
            label=name, zorder=3,
        )
        y_label = max(s["v"][-1], 0.35)  # keep the 1 nF label off the axis
        ax.text(s["t"][-1] + 3, y_label, name.split(" (")[0], color=INK2,
                fontsize=9, va="center")
    ax.annotate(
        "1 nF at 120 s: 4.5 mV\n(SN below M2 threshold,\nTP1 reads about 0)",
        xy=(120, 0.0045), xytext=(88, 3.4), fontsize=8.5, color=INK2,
        arrowprops=dict(arrowstyle="-", color=MUTED, linewidth=1),
    )
    ax.set_xlim(-3, 135)
    ax.set_ylim(0, 6.5)
    ax.set_xlabel("Time after releasing S1 (s)", color=INK2, fontsize=10)
    ax.set_ylabel("TP1 voltage (V)", color=INK2, fontsize=10)
    ax.set_title("TP1 decay after writing a 1, J1 floating", color=INK,
                 fontsize=12, loc="left", pad=12)
    ax.legend(frameon=False, loc="lower left", fontsize=9, labelcolor=INK2)
    fig.tight_layout()
    fig.savefig(IMG / "decay_curves.png", dpi=200, facecolor=SURFACE)
    plt.close(fig)


def plot_leakage(series, all_intervals):
    labels = [f"{int(r['t0'])}-{int(r['t1'])} s"
              for r in next(iter(all_intervals.values()))]
    n_groups = len(labels)
    fig, ax = plt.subplots(figsize=(7.5, 4.6), facecolor=SURFACE)
    style(ax)
    for (name, _), color in zip(series.items(), COLORS):
        pts = [(g, r["I_pA"]) for g, r in enumerate(all_intervals[name])
               if r["valid"]]
        xs, ys = zip(*pts)
        ax.plot(xs, ys, color=color, linewidth=2, marker="o", markersize=6,
                markeredgecolor=SURFACE, markeredgewidth=1.5, label=name,
                zorder=3)
    ax.set_yscale("log")
    ax.set_xlim(-0.3, n_groups - 0.7)
    ax.set_xticks(range(n_groups))
    ax.set_xticklabels(labels)
    ax.set_xlabel("Interval between readings", color=INK2, fontsize=10)
    ax.set_ylabel("Estimated leakage, C x dV/dt (pA)", color=INK2, fontsize=10)
    ax.set_title("Leakage estimate falls as the stored voltage falls", color=INK,
                 fontsize=12, loc="left", pad=12)
    handles, lbls = ax.get_legend_handles_labels()
    ax.legend(handles, lbls, frameon=False, fontsize=9, labelcolor=INK2,
              loc="upper right")
    ax.text(0.0, -0.22,
            "Meter resolution is 0.01 V, so the 100 nF values for the later "
            "intervals are only good to tens of pA.\n1 nF is omitted for "
            "60-120 s because TP1 had dropped below M2's threshold.",
            transform=ax.transAxes, fontsize=8, color=MUTED, va="top")
    fig.tight_layout()
    fig.savefig(IMG / "leakage_by_interval.png", dpi=200, facecolor=SURFACE,
                bbox_inches="tight")
    plt.close(fig)


def main():
    series = load()
    all_intervals = {name: intervals(s) for name, s in series.items()}

    with open(OUT_RESULTS, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["capacitor", "t_start_s", "t_end_s", "dV_dt_V_per_s",
                    "leakage_pA", "uncertainty_pA", "tp1_tracks_sn"])
        for name, rows in all_intervals.items():
            for r in rows:
                w.writerow([name, r["t0"], r["t1"], f"{r['slope_V_per_s']:.4f}",
                            f"{r['I_pA']:.1f}", f"{r['err_pA']:.1f}", r["valid"]])

    print(f"Retention = time for TP1 to fall {RETENTION_DROP_V} V (interpolated)")
    for name, s in series.items():
        rt = retention_time(s["t"], s["v"])
        txt = f"{rt:.1f} s" if rt is not None else f"> {s['t'][-1]:.0f} s"
        print(f"  {name:12s} retention {txt}")
        for r in all_intervals[name]:
            flag = "" if r["valid"] else "  (below threshold, ignore)"
            print(f"    {int(r['t0']):>3}-{int(r['t1']):<3} s  "
                  f"{r['slope_V_per_s']*1000:8.2f} mV/s  "
                  f"{r['I_pA']:8.1f} pA  (+/- {r['err_pA']:.1f}){flag}")

    plot_decay(series)
    plot_leakage(series, all_intervals)
    print("Wrote data/results.csv and two PNGs in images/")


if __name__ == "__main__":
    main()
